/** @file Problemas.hh
    @brief Especificación de la clase Problemas 
*/


#ifndef _PROBLEMAS_HH_
#define _PROBLEMAS_HH_

#ifndef NO_DIAGRAM
using namespace std;
#include <iostream>
#include <map>
#include <list>
#include <algorithm>
#endif 

#include "Problema.hh"

    /** @class Problemas
    @brief Representa todo el conjunto de Problemas.
    */
class Problemas
{
private:
    map<string,Problema> lista_problemas;
    static bool cmp(const pair<string,Problema>& a, const pair<string,Problema>& b);
    
public:
    //Constructoras
    /** @brief Creadora por defecto. 

        Se ejecuta automáticamente al declarar un problema.
        \pre <em>cierto</em>
        \post El resultado es un set de problemas vacío.
    */
    Problemas();
    
    /** @brief Creadora de una copia. 
        \pre <em>cierto</em>
        \post El resultado es una copia de la lista de problemas p.
    */
    Problemas(const Problemas& p);

    //Modificadoras
    /** @brief Añade al parámetro implícito el nuevo problema.
        \pre No existe ningún problema con el mismo id.
        \post El resultado és el parámetro implícito pero añadiendo el nuevo problema a este.
    */
    void afegir_problema(string id);

    //Consultoras
    /** @brief Consulta el número de probelmas que existen
        \pre <em>cierto</em>
        \post El resultado és el número de problemas que hay en total.
    */
    int num_problemas() const;

    /** @brief Consulta si existe un problema con identificador id.
        \pre <em>cierto</em>
        \post El resultado és el true si existe un problema con identificador id, y false si no exsite.
    */
    bool existe_problema(string id) const;

    //Escritura y lectura
    /** @brief Escribe por el canal standard de salida el set de problemas de forma ordenada. 
        \pre <em>cierto</em>
        \post El resultado es escribir en el canal standard de salida el set de problemas de forma ordenada.
    */
    void Escribir();

    /** @brief Escribe por el canal standard de salida el problema concreto. 
        \pre El problema identificado por id tiene que existir.
        \post El resultado es escribir en el canal standard de salida el problema si existe, de otro modo imprime un mensaje de error.
    */
    void Escribir(string id);

    /** @brief Lee por el canal standard de entrada el conjunto de problemas. 
        \pre <em>cierto</em>
        \post El resultado es leer del canal standard de entrada el conjunto de problemas y ponerlos en el parámetro implícito.
    */
    void leer(int P);
};

#endif
